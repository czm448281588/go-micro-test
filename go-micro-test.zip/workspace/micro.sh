#! /bin/bash
# Dockerfile 中 source 命令不生效，因此放到 sh 中执行
source ~/.profile
# 安装 micro、go-micro
go get github.com/micro/micro
go get github.com/micro/go-micro
go get github.com/micro/protoc-gen-micro
go get -u github.com/golang/protobuf/protoc-gen-go

# protobuf
cd /usr
git clone https://github.com/protocolbuffers/protobuf.git

cd /usr/protobuf
git submodule update --init --recursive && ./autogen.sh && ./configure && make && make check && make install